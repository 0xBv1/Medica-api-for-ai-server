<x-static-layouts title="Lung cancer" description="Lung cancer">
    <div class="content_box">
                
        <!--   Up to scroll -->
        <span class="up"><i class="fas fa-arrow-up"></i></span>

        <h1 class="banner-title">Lung cancer</h1>
        <img src="{{asset('assets/images/article_images/lung_cancer.jpg')}}" alt="" style="width: 45%;"><br><br>
        <p>
            <h2>Overview</h2><br>
            Lung cancer is a type of cancer that begins as a growth of cells in the lungs. The lungs are two spongy organs in the chest that control breathing.<br><br>

            Lung cancer is a leading cause of cancer deaths worldwide.<br><br>

            Smokers are at higher risk of developing lung cancer. The risk of lung cancer increases with the length of time you have smoked and the number of cigarettes you smoke. Quitting smoking, even after years of smoking, can greatly reduce your chances of developing lung cancer. Lung cancer can also affect people who have never smoked.<br><br>


            <h2>Symptoms</h2><br>

            Lung cancer usually doesn't cause symptoms in its early stages. Symptoms of lung cancer usually appear as the disease progresses.<br>
            Signs and symptoms of lung cancer that affects the lungs and surrounding areas may include:<br><br>

            •	A recent cough that doesn't go away.<br>
            •	Chest pain.<br>
            •	Coughing up blood, even a small amount.<br>
            •	Hoarseness.<br>
            •	Shortness of breath.<br>
            •	Wheezing.<br><br>

            Signs and symptoms that occur when lung cancer spreads to other parts of the body may include:<br><br>

            •	Bone pain.<br>
            •	Headache.<br>
            •	Unintentional weight loss.<br>
            •	Loss of appetite.<br>
            •	Swelling in the face or neck.<br><br>

            <h2>Causes</h2><br>

            Lung cancer begins when changes occur in the DNA of lung cells. The DNA of cells carries instructions that tell the cell what to do. The DNA in healthy cells also gives instructions to grow and multiply at a constant rate. The instructions tell the cells to die at a specific time. The DNA changes give different instructions in cancer cells. These changes tell cancer cells to make too many cells quickly. Cancer cells can survive while healthy cells can die. This results in too many cells.<br><br>

            Cancer cells can form a mass called a tumor. A tumor can grow and invade and destroy healthy body tissue. Over time, cancer cells can break away and spread to other parts of the body. When cancer spreads, it is called metastatic cancer.<br><br>

            Smoking causes most cases of lung cancer. It can cause lung cancer in people who smoke and in people who are exposed to secondhand smoke. But lung cancer also occurs in people who have never smoked or been exposed to secondhand smoke. There may be no clear cause for lung cancer in these people.<br><br>

            <h2>How Smoking Causes Lung Cancer</h2><br>

            Researchers believe that smoking causes lung cancer by damaging the cells that line the lungs. Cigarette smoke is full of cancer-causing substances called carcinogens. When you inhale cigarette smoke, the carcinogens cause changes in lung tissue almost immediately.<br><br>

            At first, your body may be able to repair this damage. But with each repeated exposure, the healthy cells that line the lungs become increasingly damaged. Over time, the damage causes the cells to change and eventually cancer may develop.<br><br>

            <h2>Types of lung cancer</h2><br>

            Lung cancer is divided into two main types based on how the cells look under a microscope. Your health care professional will make treatment decisions based on which main type of lung cancer you have.<br><br>

            The two main types of lung cancer are:<br><br>

            •	Small cell lung cancer. Small cell lung cancer usually occurs only in people who have smoked heavily for years. It is less common than non-small cell lung cancer.<br><br>
            •	Non-small cell lung cancer. Non-small cell lung cancer is a category that includes several types of lung cancer. Non-small cell lung cancers include squamous cell carcinoma, adenocarcinoma, and large cell carcinoma.<br><br>
            
            <h2>Risk factors</h2><br>

            There are a number of factors that can increase your risk of developing lung cancer. Some of these risk factors can be controlled, such as by quitting smoking. Others, such as your family history, cannot be controlled.<br><br>

            Risk factors for lung cancer include:<br><br>

            <h3>•	Smoking</h3><br>
            Your risk of developing lung cancer increases with the number of cigarettes you smoke each day. Your risk also increases with the number of years you have smoked. But quitting smoking at any age can greatly reduce your chances of developing lung cancer.<br><br>

            <h3>•	Exposure to secondhand smoke</h3><br>
            Even if you don’t smoke, your chances of developing lung cancer are higher if you’re around people who smoke. Breathing in the smoke from other people who smoke is called secondhand smoke.<br><br>

            <h3>•	Previous radiation therapy</h3><br>
            If you’ve had radiation therapy to your chest to treat another type of cancer, you may be at higher risk of developing lung cancer.<br><br>

            <h3>•	Radon exposure</h3><br>
            Radon is produced by the natural breakdown of uranium in soil, rocks and water. Radon eventually becomes part of the air you breathe. Any building, including homes, can accumulate dangerous levels of radon.<br><br>

            <h3>•	Exposure to cancer-causing substances</h3><br>
            Exposure to cancer-causing substances, known as carcinogens, in the workplace can increase your risk of lung cancer. Your risk may be higher if you smoke. Carcinogens linked to lung cancer risk include asbestos, arsenic, chromium and nickel.<br><br>

            <h3>•	Family history of lung cancer</h3><br>
            People who have a parent, sibling or child with lung cancer are more likely to develop lung cancer.<br><br>

            <h2>Complications</h2><br>
            Lung cancer can cause complications, such as:<br><br>

            <h3>•	Shortness of breath</h3><br>
            People with lung cancer can experience shortness of breath if the cancer grows large enough to block the main airways. Lung cancer can also cause fluid to collect around the lungs and heart. The fluid makes it difficult for the affected lung to expand fully when you breathe in.<br><br>

            <h3>•	Coughing up blood</h3><br>
            Lung cancer can cause bleeding into the airway. This can cause you to cough up blood. Sometimes the bleeding can be severe. Treatments are available to control the bleeding.<br><br>

            <h3>•	Pain</h3><br>
            Advanced lung cancer can cause pain. It can spread to the lining of the lung or to another area of the body, such as a bone. Tell your health care professional if you have pain. Treatments are available to control the pain.<br><br>

            <h3>•	Fluid in the chest</h3><br>
            Lung cancer can cause fluid to build up in the chest, called pleural effusion. The fluid collects in the space around the affected lung in the chest cavity, called the pleural space.<br><br>

            Pleural effusion can cause shortness of breath. Treatments are available to drain fluid from the chest. Treatments can reduce the risk of pleural effusion occurring again.<br><br>

            <h3>•	Cancer that spreads to other parts of the body</h3><br>
            Lung cancer often spreads to other parts of the body. It may spread to the brain and bones.<br><br>

            Cancer that spreads can cause pain, nausea, headaches, or other symptoms depending on which organ is affected. Once lung cancer spreads outside the lungs, it usually cannot be cured. Treatments are available to reduce symptoms and help you survive longer.<br><br>

            <h2>Prevention</h2><br>

            There’s no surefire way to prevent lung cancer, but you can reduce your risk if you:<br><br>

            <h3>•	Don’t smoke</h3><br>
            If you’ve never smoked, don’t start. Talk to your kids about not smoking so they can understand how to avoid this major risk factor for lung cancer. Start talking to your kids early about the dangers of smoking so they know how to handle peer pressure.<br><br>

            <h3>•	Quit smoking</h3><br>
            Quit smoking now. Quitting smoking reduces your risk of lung cancer, even if you’ve been a smoker for years. Talk to your health care team about strategies and aids that can help you quit. Options include nicotine replacement products, medications, and support groups.<br><br>

            <h3>•	Avoid secondhand smoke</h3><br>
            If you live or work with someone who smokes, encourage them to quit. At the very least, ask them to smoke outside your area. Avoid places where smokers are present, such as bars. And look for smoke-free places.<br><br>

            <h3>•	Check for radon in your home</h3><br>

            Test your home’s radon levels, especially if you live in an area where radon is known to be a problem. High radon levels can be treated to make your home safer. Radon test kits are usually available for purchase at home improvement stores and online. For more information about radon testing, contact your local public health department.<br><br>

            <h3>•	Avoid carcinogens at work</h3><br>

            Take precautions to protect yourself from exposure to toxic chemicals at work. Follow your employer’s precautions. For example, if you are given a face mask for protection, always wear it. Ask your health care professional what you can do to protect yourself at work. Your risk of lung damage from carcinogens in the workplace is higher if you smoke.<br><br>

            <h3>•	Eat a diet full of fruits and vegetables</h3><br>
            Choose a healthy diet that includes a variety of fruits and vegetables. Food sources of vitamins and nutrients are best. Avoid taking large doses of vitamins in pill form because they can be harmful. For example, researchers hoping to reduce the risk of lung cancer in heavy smokers gave beta-carotene supplements to those smokers. The results showed that these supplements increased the risk of cancer in smokers.<br><br>

            <h3>•	Exercise most days of the week</h3><br>
            If you don’t exercise regularly, start slowly. Try to exercise most days of the week.<br><br>

            <h2>When to see a doctor</h2><br>

            Make an appointment with your doctor or other health care professional if you have any symptoms that worry you.<br><br>

            If you smoke and can’t quit, make an appointment. Your health care professional can recommend strategies to help you quit smoking. These strategies may include counseling, medications, and nicotine replacement products.<br><br>

        </p> 
    </div>

</x-static-layouts>