<x-layout title="profile">
    {{-- <div class="container py-5">
        <h2 class="text-center mb-4">User Profile</h2>
        <!-- Full Name -->
<div class="row mb-3">
    <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Full Name:</div>
    <div class="col-sm-8">{{ $user->name }}</div>
  </div>
  
  <!-- Email -->
  <div class="row mb-3">
    <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Email:</div>
    <div class="col-sm-8">{{ $user->email }}</div>
  </div>
  
  <!-- Gender -->
  <div class="row mb-3">
    <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Gender:</div>
    <div class="col-sm-8">{{ ucfirst($user->gender) }}</div>
  </div>
  
  <!-- Age -->
  <div class="row mb-3">
    <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Age:</div>
    <div class="col-sm-8">{{ $user->age }}</div>
  </div>
  
  <!-- Phone -->
  <div class="row mb-3">
    <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Phone:</div>
    <div class="col-sm-8">{{ $user->phone ?? '-' }}</div>
  </div>
  
  <!-- Address -->
  <div class="row mb-3">
    <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Address:</div>
    <div class="col-sm-8">{{ $user->address ?? '-' }}</div>
  </div>
    <!-- User Predictions -->
    <div class="profile-section">
        <div class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Your Latest Predictions</div>
    
        @if($user->predictions->isEmpty())
        <p class="text-muted">No predictions available yet.</p>
        @else
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
            <thead class="table-light">
                <tr>
                <th>Model</th>
                <th>Prediction</th>
                <th>Confidence</th>
                <th>Date</th>
                </tr>
            </thead>
            <tbody>
                @foreach($user->predictions as $prediction)
                <tr>
                    <td>{{ $prediction->aiModel->name ?? '-' }}</td>
                    <td>{{ ucfirst($prediction->prediction) }}</td>
                    <td>{{ $prediction->confidence ?? ($prediction->confidanse ?? '-') }}%</td>
                    <td>{{ $prediction->created_at ? $prediction->created_at->format('d/m/Y') : '-' }}</td>
                </tr>
                @endforeach
            </tbody>
            </table>
        </div>
        @endif
    </div>
   --}}
   


<body class="profile"  style="background-color: #f8f9fa;">
  <div class="container py-5">
    <h2 class="text-center mb-4">User Profile</h2>

    <div class="profile-section" style="        background-color: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px; ">
        <div class="row">
          <!-- Profile Photo + Upload Section -->
          <div class="col-md-4 text-center">
            <img src="https://i.pravatar.cc/150?img=12" alt="Profile Photo" class="profile-img mb-3" style="width: 120px;
        height: 120px;
        border-radius: 50%;
        object-fit: cover;">
            <div>
              <button class="btn btn-outline-primary btn-sm profile-upload-btn" style="    margin-top: 10px;">Upload new photo</button>
              <p class="profile-note mt-2" style="        font-size: 0.875rem;
        color: #6c757d;">Allowed JPG or PNG. Max size of 2 MB</p>
            </div>
          </div>
  
          <!-- Basic Information Section -->
          <div class="col-md-8">
            <h5 class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Basic Information</h5>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Full Name:</div>
              <div class="col-sm-8">John Doe</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Email:</div>
              <div class="col-sm-8">john.doe@email.com</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Gender:</div>
              <div class="col-sm-8">Male</div>
            </div>
            <!-- <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Date of Birth:</div>
              <div class="col-sm-8">1990-01-01</div>
            </div> -->
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Age:</div>
              <div class="col-sm-8">44</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Phone:</div>
              <div class="col-sm-8">+201234567890</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Address:</div>
              <div class="col-sm-8">Cairo, Egypt</div>
            </div>
          </div>
        </div>
      </div>

    <!-- Smart Suggestions -->
    <div class="profile-section" style="        background-color: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px; ">
      <div class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Smart Suggestions</div>
      <ul>
        <li>Based on your history, consider uploading a new test every 3 months.</li>
        <li>Follow a diet rich in antioxidants.</li>
        <li>Maintain regular physical activity.</li>
      </ul>
    </div>

    <!-- Platform Activity -->
    <div class="profile-section" style="        background-color: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px; ">
      <div class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Platform Activity</div>
      <ul>
        <li>Last Diagnosis: 12/03/2025</li>
        <li>AI Tool Usage: 5 times</li>
        <li>Chatbot Interactions: 3 conversations</li>
      </ul>
    </div>
  </div>
  
  
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</x-layout>