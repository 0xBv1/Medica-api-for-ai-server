class Chatbox {
    constructor() {
        this.args = {
            openButton: document.querySelector('.chatbox__button'),
            chatBox: document.querySelector('.chatbox__support'),
            sendButton: document.querySelector('.send__button'),
            inputField: document.querySelector('.chatbox__input')
        };

        this.state = false;
        this.messages = [];
        this.recognition = null;
        this.isRecording = false;

        this.initSpeechRecognition();
        this.clearInputField();
    }

    display() {
        const { openButton, chatBox, sendButton, inputField } = this.args;
    
        openButton.addEventListener('click', () => this.toggleState(chatBox));
    
        sendButton.addEventListener('click', () => {
            const inputText = inputField.value.trim();
    
            if (this.isRecording) {
                this.stopRecording();
            } else if (inputText !== "") {
                this.onSendButton(chatBox);
            } else {
                this.startRecording();
            }
        });
    
        inputField.addEventListener("keyup", ({ key }) => {
            if (key === "Enter") {
                this.onSendButton(chatBox);
            }
        });
    
        inputField.addEventListener("input", () => this.updateSendButton());
    }

    // Make sure the text field is empty on load
    clearInputField() {
        this.args.inputField.value = '';
    }

    toggleState(chatbox) {
        this.state = !this.state;

        if (this.state) {
            chatbox.style.visibility = "visible";
            chatbox.classList.add('chatbox--active');
        } else {
            chatbox.classList.remove('chatbox--active');
            setTimeout(() => {
                if (!this.state) {
                    chatbox.style.visibility = "hidden";
                }
            }, 400);
        }
    }

    onSendButton(chatbox) {
        const textField = this.args.inputField;
        let text1 = this.sanitizeInput(textField.value.trim()); // Sanitize input
        if (text1 === "") return;

        // Clear the text field right after sending the message
        textField.value = '';
        this.updateSendButton();

        let msg1 = { name: "User", message: text1 };
        this.messages.push(msg1);
        this.updateChatText(chatbox);

        // Call the text_to_text API
        this.textToText(text1).then(response => {
            let msg2 = { name: "Sam", message: this.sanitizeInput(response.gemini_response) }; // Sanitize output
            this.messages.push(msg2);
            this.updateChatText(chatbox);
            
            // إضافة زرار لقراءة الرد بصوت
            let readButton = document.createElement("button");
            readButton.textContent = "🔊";
            readButton.classList.add("read-button");
            
            readButton.addEventListener("click", () => this.speakText(response.gemini_response));
            
            chatbox.querySelector(".chatbox__messages").appendChild(readButton);
        }).catch(error => {
            console.error('Error:', error);
            this.updateChatText(chatbox);
        });
    }

    // Text-to-text API
    async textToText(message) {
        const url = "https://shadowtem-chatbot.hf.space/text_to_text";
        const payload = {
            message: message,
            Saved_response: ""
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const data = await response.json();
            return data;
        } catch (error) {
            console.error("Error during API request:", error);
            throw error;
        }
    }

    updateChatText(chatbox) {
        const chatMessagesContainer = chatbox.querySelector('.chatbox__messages');
        chatMessagesContainer.innerHTML = '';

        this.messages.forEach(item => {
            let messageDiv = document.createElement('div');
            messageDiv.classList.add('messages__item');

            if (item.name === "Sam") {
                messageDiv.classList.add('messages__item--visitor');
            } else {
                messageDiv.classList.add('messages__item--operator');
            }

            messageDiv.textContent = item.message;
            chatMessagesContainer.appendChild(messageDiv);
        });

        let lastMessage = chatMessagesContainer.lastElementChild;
        if (lastMessage) {
            lastMessage.style.marginBottom = "30px";
        }

        setTimeout(() => {
            chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight;
        }, 100);
    }

    initSpeechRecognition() {
        if (!window.SpeechRecognition && !window.webkitSpeechRecognition) {
            console.warn("The browser does not support voice recognition!");
            return;
        }

        this.recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        this.recognition.lang = "ar-EG";
        this.recognition.continuous = false;
        this.recognition.interimResults = false;

        this.recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            this.args.inputField.value = transcript;
            this.updateSendButton();
        };

        this.recognition.onerror = (event) => {
            console.error("Voice recognition error:", event.error);
        };
    }

    startRecording() {
        if (!this.recognition) return;
        this.isRecording = true;
        this.recognition.start();
        this.args.sendButton.classList.add("listening");
        this.updateSendButton();
    }

    stopRecording() {
        if (!this.recognition) return;
        this.isRecording = false;
        this.recognition.stop();
        this.args.sendButton.classList.remove("listening");
        this.updateSendButton();
    }

    speakText(text) {
        let utterance = new SpeechSynthesisUtterance(text);
        speechSynthesis.speak(utterance);
    }

    updateSendButton() {
        const { sendButton, inputField } = this.args;
        if (this.isRecording) {
            sendButton.innerHTML = '<i class="fa fa-stop"></i>';
        } else if (inputField.value.trim() !== "") {
            sendButton.innerHTML = '<i class="fa fa-paper-plane"></i>';
        } else {
            sendButton.innerHTML = '<i class="fa fa-microphone"></i>';
        }
    }

    // Function to sanitize inputs and outputs
    sanitizeInput(input) {
        const doc = new DOMParser().parseFromString(input, 'text/html');
        return doc.body.textContent || "";
    }
}

// Initialize the chatbox
const chatbox = new Chatbox();
chatbox.display();
