<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AiModel extends Model
{
    protected $table = 'models'; // لو مش هتغير اسم الجدول في DB

    protected $fillable = [
        'name',
        'type',
    ];
}