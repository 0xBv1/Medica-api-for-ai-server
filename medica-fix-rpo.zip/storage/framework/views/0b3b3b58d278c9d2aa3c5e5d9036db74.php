<?php if (isset($component)) { $__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth','data' => ['title' => 'Reset Password - Medica']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Reset Password - Medica']); ?>

  <div class="sign_container">
      <div class="sign_img">
          <img src="<?php echo e(asset('assets/images/Medica_icon_1.png')); ?>" alt="" onclick="window.location.href='<?php echo e(route('home')); ?>'">
      </div>
      <h2>Reset Password</h2>
      <p>Enter your email to receive password reset instructions</p>

      <?php if(session('status')): ?>
          <div style="color: green; margin-bottom: 10px;">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('password.email')); ?>">
          <?php echo csrf_field(); ?>
          <div class="sign_input-group">
              <label for="email">Email Address</label>
              <input type="email" id="email" name="email" placeholder="Enter your Email" value="<?php echo e(old('email')); ?>" required>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small style="color: red"><?php echo e($message); ?></small>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <button class="sign_button" type="submit">Send Reset Link</button>
      </form>

      <div class="sign_footer">
          Remembered it? <a href="<?php echo e(route('login')); ?>">Back to Sign In</a>
      </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2)): ?>
<?php $attributes = $__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2; ?>
<?php unset($__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2)): ?>
<?php $component = $__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2; ?>
<?php unset($__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\medica-fix-rpo\resources\views/auth/forgot_password.blade.php ENDPATH**/ ?>