<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'profile']); ?>
    
   


<body class="profile"  style="background-color: #f8f9fa;">
  <div class="container py-5">
    <h2 class="text-center mb-4">User Profile</h2>

    <div class="profile-section" style="        background-color: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px; ">
        <div class="row">
          <!-- Profile Photo + Upload Section -->
          <div class="col-md-4 text-center">
            <img src="https://i.pravatar.cc/150?img=12" alt="Profile Photo" class="profile-img mb-3" style="width: 120px;
        height: 120px;
        border-radius: 50%;
        object-fit: cover;">
            <div>
              <button class="btn btn-outline-primary btn-sm profile-upload-btn" style="    margin-top: 10px;">Upload new photo</button>
              <p class="profile-note mt-2" style="        font-size: 0.875rem;
        color: #6c757d;">Allowed JPG or PNG. Max size of 2 MB</p>
            </div>
          </div>
  
          <!-- Basic Information Section -->
          <div class="col-md-8">
            <h5 class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Basic Information</h5>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Full Name:</div>
              <div class="col-sm-8">John Doe</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Email:</div>
              <div class="col-sm-8">john.doe@email.com</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Gender:</div>
              <div class="col-sm-8">Male</div>
            </div>
            <!-- <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;"">Date of Birth:</div>
              <div class="col-sm-8">1990-01-01</div>
            </div> -->
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Age:</div>
              <div class="col-sm-8">44</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Phone:</div>
              <div class="col-sm-8">+201234567890</div>
            </div>
            <div class="row mb-3">
              <div class="col-sm-4 profile-info-label "style="font-weight: 500;
        color: #333;">Address:</div>
              <div class="col-sm-8">Cairo, Egypt</div>
            </div>
          </div>
        </div>
      </div>

    <!-- Smart Suggestions -->
    <div class="profile-section" style="        background-color: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px; ">
      <div class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Smart Suggestions</div>
      <ul>
        <li>Based on your history, consider uploading a new test every 3 months.</li>
        <li>Follow a diet rich in antioxidants.</li>
        <li>Maintain regular physical activity.</li>
      </ul>
    </div>

    <!-- Platform Activity -->
    <div class="profile-section" style="        background-color: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px; ">
      <div class="profile-section-title "style="        font-weight: 600;
        font-size: 1.2rem;
        margin-bottom: 20px;">Platform Activity</div>
      <ul>
        <li>Last Diagnosis: 12/03/2025</li>
        <li>AI Tool Usage: 5 times</li>
        <li>Chatbot Interactions: 3 conversations</li>
      </ul>
    </div>
  </div>
  
  
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\medica-fix-rpo\resources\views/auth/profile.blade.php ENDPATH**/ ?>