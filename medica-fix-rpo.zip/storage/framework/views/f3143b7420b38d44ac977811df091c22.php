<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo e($title); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href=<?php echo e(asset('/../assets/css/auth.css')); ?>>    
  </head>
  <body>
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\medica-fix-rpo\resources\views/components/auth.blade.php ENDPATH**/ ?>