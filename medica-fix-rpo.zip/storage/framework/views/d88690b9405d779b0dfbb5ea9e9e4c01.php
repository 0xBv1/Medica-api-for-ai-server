<?php if (isset($component)) { $__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth','data' => ['title' => 'Email Verification - Medica']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Email Verification - Medica']); ?>
<div class="sign_container">
    <div class="sign_img">
      <img src="<?php echo e(asset('assets/images/Medica_icon_1.png')); ?>" alt="" onclick="window.location.href='<?php echo e(route('home')); ?>'">
    </div>
    <h2>Email Verification</h2>
    <p>We’ve sent a verification link to your email address. Please check your inbox and verify your account.</p>

    <?php if(session('status') == 'verification-link-sent'): ?>
      <p style="color: green; text-align:center; font-size: 14px;">A new verification link has been sent to your email.</p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('verification.resend')); ?>">
              <?php echo csrf_field(); ?>
      <button class="sign_button" type="submit">Resend Verification Email</button>
    </form>

    <div class="sign_footer">
      Already verified? <a href="<?php echo e(route('home')); ?>">Go to Homepage</a>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2)): ?>
<?php $attributes = $__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2; ?>
<?php unset($__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2)): ?>
<?php $component = $__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2; ?>
<?php unset($__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\medica-fix-rpo\resources\views/auth/verify_email.blade.php ENDPATH**/ ?>