<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\medica-fix-rpo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>