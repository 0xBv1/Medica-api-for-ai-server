<?php

namespace App\Providers;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\EnsureFrontendRequestsAreStateful;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Route::middleware([
            EnsureFrontendRequestsAreStateful::class,
            // أي Middleware تاني تحب تضيفه هنا
        ])->group(function () {
            // هنا ممكن تحط أي routes خاصة بالمجموعة دي لو حابب
        });
    }
}
