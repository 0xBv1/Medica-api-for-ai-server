<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

class Handler extends ExceptionHandler
{
    /**
     * سجل أي استثناءات غير مُعالجة هنا.
     */
    public function register(): void
    {
        $this->renderable(function (TooManyRequestsHttpException $e, Request $request) {
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'عدد الطلبات كبير جدًا. حاول مرة أخرى بعد قليل.',
                ], 429);
            }

            return redirect()->back()->withErrors([
                'rate_limit' => 'عدد المحاولات كبير جدًا، برجاء المحاولة لاحقًا.',
            ])->withInput();
        });
    }
}
