<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AiModel extends Model
{
    protected $table = 'models'; 

    protected $fillable = [
        'name',
        'type',
    ];
}